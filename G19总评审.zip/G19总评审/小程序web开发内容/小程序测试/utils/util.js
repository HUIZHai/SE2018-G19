const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const min = date.getMinutes()
  const time = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, min, time].map(formatNumber).join(':')
}
function formatTime1(time, format1) {
  let temp = '0000000000' + time
  let len = format1.length
  return temp.substr(-len)
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}
module.exports = {
  formatTime: formatTime,
  formatTime1: formatTime1
}
